package inter;

import lexer.Token;
import symbols.Type;

public class Range extends Expr {

	public Expr low, high;
	private boolean constants;
	private int leftint, rightint;
	
	public Range(Expr left, Expr right) {
		super(null, null);
		
		low = left;
		high = right;
		if ((low.type != Type.Int) || (high.type != Type.Int))
			error("type error");
		try
		{
			leftint = Integer.valueOf(left.toString());
			rightint = Integer.valueOf(right.toString());
			constants = true;
		}
		catch (NumberFormatException e)
		{
			constants = false;
		}
	}

	public Expr gen() 
	{
		if (constants)
			return new Constant(rightint - leftint + 1);
		
		Temp templow = new Temp(Type.Int);
		emit(templow + " = " + low.gen());
		low = templow;
		
		Temp temphigh = new Temp(Type.Int);
		emit(temphigh + " = " + high.gen());
		high = temphigh;
		
		Arith a = new Arith(new Token('-'), high, low);
		Arith b = new Arith(new Token('+'), a, new Constant(1));
		Expr c = b.gen();
		
		Temp after = new Temp(Type.Int);
		emit(after.toString() + " = " + c);
		return after;
	}
	
	public String toString() {
		return String.valueOf(low) + " .. " + String.valueOf(high);
	}
}
