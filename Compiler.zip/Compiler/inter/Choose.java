package inter;

import java.util.ArrayList;

import lexer.Num;
import lexer.Token;
import symbols.Type;

public class Choose extends Stmt {
	ArrayList<Expr> probs;
	ArrayList<Stmt> statements;
	boolean constant;
	
	public Choose(ArrayList<Expr> probs, ArrayList<Stmt> statements, boolean constant) {
		this.probs = probs;
		this.statements = statements;
		this.constant = constant;
		if (probs.size() != statements.size())
			error("syntax error");
	}
	
	public void gen(int b, int a) {
		if (probs.size() == 1)
			statements.get(0).gen(b, a);
		else if (constant)
			genconstant(b, a);
		else
			gendynamic(b, a);
	}

	private void gendynamic(int b, int a) {
		Token plus = new Token('+');
		ArrayList<Temp> checkpoints = new ArrayList<Temp>();
		Temp tsum = new Temp(Type.Int);
		
		emit( tsum.toString() + " = 0" );
		for (int i = 0; i < probs.size(); i++)
		{
			Arith addition = new Arith(plus, tsum, probs.get(i));
			tsum = new Temp(Type.Int);
			emit( tsum + " = " + addition.gen().toString() );
		
			checkpoints.add(tsum);
		}

		Temp t = new Temp(Type.Int);
		emit( "rand " + t.toString() + " " + tsum.toString() );
		
		int label1 = 0;
		int label2 = 0;
		for (int i = 0; i < probs.size() - 1; i++)
		{
			if (label1 != 0)
				emitlabel(label1);
			label1 = newlabel();
			emit( "iffalse " + t.toString() + " < " + 
					checkpoints.get(i) + 
					" goto L" + label1);
			label2 = newlabel(); 
			statements.get(i).gen(label2, a); 
			emit("goto L" + a);
		}
		emitlabel(label1);
		statements.get(statements.size() - 1).gen(label2, a); 
	}

	private void genconstant(int b, int a) {
		int probsum = 0;
		for (Expr i : probs)
			probsum += ((Num)i.op).value;

		Temp t = new Temp(Type.Int);
		emit( "rand " + t.toString() + " " + String.valueOf(probsum) );
		
		int partialsum = 0;
		int label1 = 0;
		int label2 = 0;
		for (int i = 0; i < probs.size() - 1; i++)
		{
			partialsum += ((Num)probs.get(i).op).value;
			if (label1 != 0)
				emitlabel(label1);
			label1 = newlabel();
			emit( "iffalse " + t.toString() + " < " + 
					String.valueOf(partialsum) + 
					" goto L" + label1);
			label2 = newlabel(); 
			statements.get(i).gen(label2, a); 
			emit("goto L" + a);
		}
		emitlabel(label1);
		statements.get(statements.size() - 1).gen(label2, a); 
	}
}
