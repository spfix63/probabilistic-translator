package inter;

import symbols.Type;


public class SetRange extends Stmt {
	
	public Id id;
	public Range range;

	public SetRange(Id i, Range r) {
		id = i;
		range = r;
		if ( id.type != Type.Int ) error("type error");
	}

	public void gen(int b, int a) {
		emit( "rand " + id.toString() + " " + range.gen() );
		emit( id.toString() + 
				" = " + id.toString() + 
				" + " + range.low );
	}
}
